import logging

__version__ = "1.5.0dev"
__codename__ = "ToeCutter"

logging.getLogger("witnessme").addHandler(logging.NullHandler())
