# Klass comment.
class Klass
  def meth
    x = 5
  end
end
