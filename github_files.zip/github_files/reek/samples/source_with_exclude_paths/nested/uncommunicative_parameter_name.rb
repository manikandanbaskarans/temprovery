# Klass comment
class Klass
  def method(a)
    a + @x
  end
end
