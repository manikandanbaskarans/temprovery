class Klass
end
