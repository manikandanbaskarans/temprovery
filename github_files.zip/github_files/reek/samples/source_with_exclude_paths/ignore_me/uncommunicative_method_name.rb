# Klass comment.
class Klass
  def m
  end
end
