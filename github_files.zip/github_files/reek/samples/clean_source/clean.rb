# Well documented Clean class.
class Clean
  def hello(argument)
    say argument
  end
end
