# frozen_string_literal: true

require_relative 'code_climate/code_climate_fingerprint'
require_relative 'code_climate/code_climate_formatter'
require_relative 'code_climate/code_climate_report'
